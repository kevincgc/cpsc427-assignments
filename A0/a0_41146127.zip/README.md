Kevin Cai
41146127
Compiled with VS2019 Community on Windows.

// This defines the struct for the SoA implementation. It has arrays for both position and velocity in the same struct.
// The [0] element represents x and [1] element represents y.
	struct PositionVelocity {
		float position[2];
		float velocity[2];
		PositionVelocity(float x_pos, float y_pos, float x_vel, float y_vel) : 
			position { x_pos, y_pos	}, velocity{ x_vel, y_vel } {};
	};

// This defines the struct for the AoS implementation. It is a generic struct for 2D that takes an (x, y) value.
	struct Value2D {
		float x;
		float y;
		Value2D(float x, float y) : x(x), y(y) {};
	};

// I initialized the Components. I chose to use a pointer to a Value2D array to for AoS. 
// position_velocity_aos[0] is the position and position_velocity_aos[1] is the velocity.
	ComponentContainer<PositionVelocity> position_velocity_soa;
	ComponentContainer<Value2D*> position_velocity_aos;

// I added the AoS component to the fish and set its position to (1,6) and velocity to (2,2).
// A 2 element array of Value2D is created and a pointer to the first element is added to the component.
	registry.position_velocity_aos.insert(fish, (Value2D*) std::begin({ Value2D(1, 6), Value2D(2, 2) }));

// I added the SoA component to the turtle and set its position to (4,2) and velocity to (0,3)
	registry.position_velocity_soa.insert(turtle, PositionVelocity(4, 2, 0, 3));

// I printed the position+velocity of the fish and turtle.
	std::cout << registry.names.get(fish).name << " is at (" << registry.position_velocity_aos.get(fish)[0].x
		<< ',' << registry.position_velocity_aos.get(fish)[0].y << ") with velocity ("
		<< registry.position_velocity_aos.get(fish)[1].x << ',' << registry.position_velocity_aos.get(fish)[1].y
		<< ") using AoS" << std::endl;
	std::cout << registry.names.get(turtle).name << " is at (" << registry.position_velocity_soa.get(turtle).position[0]
		<< ',' << registry.position_velocity_soa.get(turtle).position[1] << ") with velocity ("
		<< registry.position_velocity_soa.get(turtle).velocity[0] << ',' << registry.position_velocity_soa.get(turtle).velocity[1]
		<< ") using SoA" << std::endl;